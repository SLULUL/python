import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.decomposition import PCA
import numpy as np
iris = load_iris()
X = iris.data
y = iris.target
# print(X.shape)
pca = PCA(n_components=2)
pca = pca.fit(X)
X_dr = pca.transform(X)
# print(X_dr.shape)
# print(y == 0)
# print(X_dr[y == 0, 0])
# plt.figure()
# plt.scatter(X_dr[y == 0, 0], X_dr[y == 0, 1],
#             c='red', label=iris.target_names[0])
# plt.scatter(X_dr[y == 1, 0], X_dr[y == 1, 1],
#             c='black', label=iris.target_names[1])
# plt.scatter(X_dr[y == 2, 0], X_dr[y == 2, 1],
#             c='orange', label=iris.target_names[2])
# plt.legend()
# plt.title('PCA of IRIS dataset')
# plt.show()
# print(pca.explained_variance_)
# print(pca.explained_variance_ratio_)
# print(pca.explained_variance_ratio_.sum())
pca_line = PCA().fit(X)
# print(pca_line.explained_variance_ratio_)
# print(np.cumsum(pca_line.explained_variance_ratio_))
# plt.plot(np.arange(1, 5), np.cumsum(pca_line.explained_variance_ratio_))
# plt.xticks(np.arange(1, 5))
# plt.xlabel('Number of components after dimensionality reduction')
# plt.ylabel('Cumulative explained variance')
# plt.show()

# n_components的不同取值方式
pca_mle = PCA(n_components='mle').fit(X)
print("MLE选择的维数:", pca_mle.n_components_)
pca_095 = PCA(n_components=0.95).fit(X)
print("保留95%方差选择的维数:", pca_095.n_components_)
pca_all = PCA(n_components=None).fit(X)
print("保留所有成分的维数:", pca_all.n_components_)
